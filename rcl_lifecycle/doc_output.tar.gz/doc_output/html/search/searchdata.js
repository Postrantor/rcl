var indexSectionsWithContent =
{
  0: "acegilmnoprstv",
  1: "r",
  2: "acegilmnopstv",
  3: "r"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "variables",
  3: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Variables",
  3: "Pages"
};

